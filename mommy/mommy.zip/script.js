let propertyRecords = [];
let editingIndex = -1;

// File data storage
let currentFiles = {
    cct: null,
    tct: null,
    contract: null,
    deedSale: null,
    deedAssign: null
};

// Load data when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadDataFromStorage();
    displayRecords();
    
    // Title type change event
    document.getElementById('titleType').addEventListener('change', function() {
        if (this.value === 'cct') {
            document.getElementById('cctSection').style.display = 'block';
            document.getElementById('tctSection').style.display = 'none';
        } else if (this.value === 'tct') {
            document.getElementById('cctSection').style.display = 'none';
            document.getElementById('tctSection').style.display = 'block';
        } else {
            document.getElementById('cctSection').style.display = 'none';
            document.getElementById('tctSection').style.display = 'none';
        }
    });
    
    // SPA status change event
    document.getElementById('spaStatus').addEventListener('change', function() {
        if (this.value === 'yes') {
            document.getElementById('spaTypeSection').style.display = 'block';
        } else {
            document.getElementById('spaTypeSection').style.display = 'none';
        }
    });
    
    // File input change events
    document.getElementById('cctFile').addEventListener('change', function(e) {
        handleFileSelect(e, 'cct');
    });
    
    document.getElementById('tctFile').addEventListener('change', function(e) {
        handleFileSelect(e, 'tct');
    });
    
    document.getElementById('contractFile').addEventListener('change', function(e) {
        handleFileSelect(e, 'contract');
    });
    
    document.getElementById('deedSaleFile').addEventListener('change', function(e) {
        handleFileSelect(e, 'deedSale');
    });
    
    document.getElementById('deedAssignFile').addEventListener('change', function(e) {
        handleFileSelect(e, 'deedAssign');
    });
});

// Function to handle file selection
function handleFileSelect(event, fileType) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    const fileSize = formatFileSize(file.size);
    
    reader.onload = function(e) {
        const fileData = {
            name: file.name,
            type: file.type,
            size: fileSize,
            lastModified: file.lastModified,
            content: e.target.result
        };
        
        currentFiles[fileType] = fileData;
        
        // Update preview
        updateFilePreview(fileType, fileData);
    };
    
    reader.readAsDataURL(file);
}

// Update file preview
function updateFilePreview(fileType, fileData) {
    const previewElement = document.getElementById(`${fileType}Preview`);
    const fileView = document.getElementById(`${fileType}FileView`);
    const fileSizeElement = document.getElementById(`${fileType}FileSize`);
    
    if (!previewElement) return;
    
    previewElement.style.display = 'block';
    fileSizeElement.textContent = fileData.size;
    
    if (fileData.type.includes('image')) {
        fileView.innerHTML = `<img src="${fileData.content}" alt="${fileData.name}">`;
    } else if (fileData.type === 'application/pdf') {
        fileView.innerHTML = `<iframe class="pdf-preview" src="${fileData.content}" type="application/pdf"></iframe>`;
    } else {
        fileView.innerHTML = `<div>File attached: ${fileData.name}</div>`;
    }
}

// Format file size
function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' bytes';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
}

// Load data from localStorage
function loadDataFromStorage() {
    try {
        const savedRecords = localStorage.getItem('propertyRecords');
        if (savedRecords) {
            propertyRecords = JSON.parse(savedRecords);
        }
    } catch (error) {
        console.error('Error loading data:', error);
        propertyRecords = [];
    }
}

// Switch between tabs
function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.getElementById(tabId).classList.add('active');
    
    // Find the tab button that was clicked
    const tabs = document.querySelectorAll('.tab');
    for (let i = 0; i < tabs.length; i++) {
        if (tabs[i].getAttribute('onclick').includes(tabId)) {
            tabs[i].classList.add('active');
        }
    }
}

// Save record function
function saveRecord() {
    const record = {
        name: document.getElementById('name').value,
        address: document.getElementById('address').value,
        bdate: document.getElementById('bdate').value,
        property: document.getElementById('property').value,
        tinNumber: document.getElementById('tinNumber').value,
        unitNo: document.getElementById('unitNo').value,
        developer: document.getElementById('developer').value,
        dateJoined: document.getElementById('dateJoined').value,
        taxDecType: document.getElementById('taxDecType').value,
        taxDecNumber: document.getElementById('taxDecNumber').value,
        titleType: document.getElementById('titleType').value,
        titleNumber: document.getElementById('titleType').value === 'cct' ? 
                     document.getElementById('cctNumber').value : 
                     document.getElementById('tctNumber').value,
        turnoverDate: document.getElementById('turnoverDate').value,
        spaStatus: document.getElementById('spaStatus').value,
        spaType: document.getElementById('spaStatus').value === 'yes' ? 
                 document.getElementById('spaType').value : '',
        documents: {
            contract: {
                received: document.getElementById('contractReceived').value,
                returned: document.getElementById('contractReturned').value,
                signed: document.getElementById('contractSigned').value
            },
            deedSale: {
                received: document.getElementById('deedSaleReceived').value,
                returned: document.getElementById('deedSaleReturned').value,
                signed: document.getElementById('deedSaleSigned').value
            },
            deedAssign: {
                received: document.getElementById('deedAssignReceived').value,
                returned: document.getElementById('deedAssignReturned').value,
                signed: document.getElementById('deedAssignSigned').value
            }
        },
        files: {
            cct: currentFiles.cct,
            tct: currentFiles.tct,
            contract: currentFiles.contract,
            deedSale: currentFiles.deedSale,
            deedAssign: currentFiles.deedAssign
        },
        timestamp: new Date().toISOString()
    };
    
    if (editingIndex >= 0) {
        propertyRecords[editingIndex] = record;
        editingIndex = -1;
        document.getElementById('saveBtn').textContent = 'Save Record';
    } else {
        propertyRecords.push(record);
    }
    
    // Save to localStorage
    try {
        localStorage.setItem('propertyRecords', JSON.stringify(propertyRecords));
        
        // Show success message
        const successMessage = document.getElementById('successMessage');
        successMessage.style.display = 'block';
        successMessage.textContent = 'Record saved successfully!';
        
        setTimeout(function() {
            successMessage.style.display = 'none';
        }, 3000);
        
        clearForm();
        displayRecords();
        switchTab('recordsTab');
    } catch (e) {
        if (e.name === 'QuotaExceededError') {
            alert('Storage limit exceeded. Try removing some files or records.');
        } else {
            alert('Error saving record: ' + e.message);
        }
    }
}

// Display records function
function displayRecords() {
    const recordsList = document.getElementById('recordsList');
    recordsList.innerHTML = '';
    
    propertyRecords.forEach((record, index) => {
        const row = document.createElement('tr');
        
        // Count how many documents are attached
        let docCount = 0;
        if (record.files) {
            if (record.files.cct) docCount++;
            if (record.files.tct) docCount++;
            if (record.files.contract) docCount++;
            if (record.files.deedSale) docCount++;
            if (record.files.deedAssign) docCount++;
        }
        
        // Create document status summary
        let docStatus = '';
        if (record.titleType) docStatus += `${record.titleType.toUpperCase()}: ${record.titleNumber}<br>`;
        if (record.taxDecType) docStatus += `Tax Dec: ${record.taxDecType === 'developer' ? 'Developer' : 'Client'}<br>`;
        if (record.turnoverDate) docStatus += `Turnover: ${new Date(record.turnoverDate).toLocaleDateString()}<br>`;
        if (docCount > 0) docStatus += `<span class="file-badge">${docCount} document${docCount > 1 ? 's' : ''} attached</span>`;
        
        row.innerHTML = `
            <td>${record.name}</td>
            <td>${record.property}<br><small>${record.unitNo || ''}</small></td>
            <td>${record.developer}</td>
            <td>${docStatus}</td>
            <td>
                <button onclick="viewRecord(${index})">View</button>
                <button onclick="editRecord(${index})">Edit</button>
                <button onclick="deleteRecord(${index})">Delete</button>
            </td>
        `;
        recordsList.appendChild(row);
    });
}

// View record details
function viewRecord(index) {
    editRecord(index);
    // Make form fields readonly for viewing
    const inputs = document.querySelectorAll('#propertyForm input, #propertyForm select');
    inputs.forEach(input => {
        if (input.type !== 'file') {
            input.setAttribute('readonly', true);
            if (input.tagName === 'SELECT') {
                input.style
                input.style.pointerEvents = 'none';
            }
        }
    });
    
    document.getElementById('saveBtn').style.display = 'none';
    switchTab('formTab');
}

// Edit record
function editRecord(index) {
    const record = propertyRecords[index];
    editingIndex = index;
    
    document.getElementById('name').value = record.name;
    document.getElementById('address').value = record.address;
    document.getElementById('bdate').value = record.bdate;
    document.getElementById('property').value = record.property;
    document.getElementById('tinNumber').value = record.tinNumber;
    document.getElementById('unitNo').value = record.unitNo;
    document.getElementById('developer').value = record.developer;
    document.getElementById('dateJoined').value = record.dateJoined;
    document.getElementById('taxDecType').value = record.taxDecType;
    document.getElementById('taxDecNumber').value = record.taxDecNumber;
    document.getElementById('titleType').value = record.titleType;
    document.getElementById(record.titleType === 'cct' ? 'cctNumber' : 'tctNumber').value = record.titleNumber;
    document.getElementById('turnoverDate').value = record.turnoverDate;
    document.getElementById('spaStatus').value = record.spaStatus;
    if (record.spaStatus === 'yes') {
        document.getElementById('spaType').value = record.spaType;
    }
    
    document.getElementById('contractReceived').value = record.documents.contract.received;
    document.getElementById('contractReturned').value = record.documents.contract.returned;
    document.getElementById('contractSigned').value = record.documents.contract.signed;
    
    document.getElementById('deedSaleReceived').value = record.documents.deedSale.received;
    document.getElementById('deedSaleReturned').value = record.documents.deedSale.returned;
    document.getElementById('deedSaleSigned').value = record.documents.deedSale.signed;
    
    document.getElementById('deedAssignReceived').value = record.documents.deedAssign.received;
    document.getElementById('deedAssignReturned').value = record.documents.deedAssign.returned;
    document.getElementById('deedAssignSigned').value = record.documents.deedAssign.signed;
    
    document.getElementById('saveBtn').textContent = 'Update Record';
    document.getElementById('saveBtn').style.display = 'block';
    
    switchTab('formTab');
}

// Delete record
function deleteRecord(index) {
    if (confirm('Are you sure you want to delete this record?')) {
        propertyRecords.splice(index, 1);
        localStorage.setItem('propertyRecords', JSON.stringify(propertyRecords));
        displayRecords();
    }
}

// Clear form
function clearForm() {
    document.getElementById('propertyForm').reset();
    editingIndex = -1;
    document.getElementById('saveBtn').textContent = 'Save Record';
}
